#include "Structures_et_Fonctions_etiquettes.h"
#include "Fonctions_outils.h"
#include "Constantes.h"
#include <stdio.h>
#include <stdlib.h>
extern int nbEtiq;
extern int instr_count;
extern unsigned int adresse_courante;
extern int ligne_num;
extern Etiquette *tab_etiq[MAX_ETIQ];




Etiquette* chercher_etiquette(char *nom){
    for(int i=0;i<nbEtiq;i++){
        if (comparer_char(tab_etiq[i]->etiquette,nom)==0){
            return tab_etiq[i];
        }
    }
    return NULL; // étiquette non trouvée
}

Etiquette  *ajouter_etiquette(char *nom) {
    if (nom == NULL) {
        printf("Erreur : Etiquette vide.\n");
        return NULL;
    }

    if (nbEtiq >= MAX_ETIQ) {
        printf("Erreur : Nombre maximum d'etiquettes atteint.\n");
        return NULL;
    }

    if (chercher_etiquette(nom) != NULL) {
        printf("Erreur Ligne :%d  Etiquette deja definie : %s\n", ligne_num, nom);
        return NULL;
    }
    
    for (int i = 0; nom[i] != '\0'; i++){
        char c = nom[i];
        if (!((c>='a'&&c<='z') || (c>='A'&&c<='Z') || (c>='0'&&c<='9') || c=='_')){
            printf("Erreur : ligne %d Caracteres interdits dans l'etiquette\n",ligne_num);
            return NULL;}
    }
    char *nom_etiq=malloc(sizeof(char)*taille(nom)+1);
    copier_char(nom_etiq,nom,taille(nom)+1);
    Etiquette *etiq=malloc(sizeof(Etiquette));
    etiq->adresse=adresse_courante;
    etiq->etiquette=nom_etiq;
    return etiq;
}

int chercher_adresse_dans_etiquettes(unsigned int x){
    int i;
    for(i=0;i<nbEtiq;i++){
        if (tab_etiq[i]->adresse==x){
            return 1;
        }

    }
    return 0;
}
void afficher_etiquettes(){
    printf("Liste des etiquettes :\n");
    for(int i=0;i<nbEtiq;i++){
        printf("Etiquette: %s, Adresse: %d\n", tab_etiq[i]->etiquette, tab_etiq[i]->adresse);
    }
}
