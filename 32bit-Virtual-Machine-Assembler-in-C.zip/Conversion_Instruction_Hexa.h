#ifndef CONVERSION_INSTRUCTION_HEXA_H
#define CONVERSION_INSTRUCTION_HEXA_H
#include "Structures_et_Fonctions_instructions.h"
#include "Fonctions_outils.h"
// renvoie x puissance n
int power(int x, int n);
// la chaine de caractères représentant n sur bits bits non signés
char *convertion_binaire_sans_signe(int n, int bits);
// la chaine de caractères représentant n sur bits bits signés
char *convertion_binaire_signe(int n, int bits);
// Prend une instruction en entrée et renvoie son format binaire.
char *Instruction_binaire(Instruction *I);
// Prend une chaine binaire de 32 bits et renvoie sa forme hexadécimal
char *Binaire32_vers_hexa(char *m);
#endif

