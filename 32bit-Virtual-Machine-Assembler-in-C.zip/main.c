
#include "Fonctions_outils.h"
#include "Structures_et_Fonctions_etiquettes.h"
#include "Structures_et_Fonctions_instructions.h"
#include "Conversion_Instruction_Hexa.h"
#include "Constantes.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "Gestion_memoire.h"

// Variables globales Traduction Assembleur
Etiquette *tab_etiq[MAX_ETIQ];
int nbEtiq=0; 
Instruction *tab_instr[MAX_INSTR];
int nbInstr=0;
int adresse_courante=0;
int ligne_num=0;
char ligne[MAX_LIGNE_LONG];
// Variables globales Execution
int registres[32];
int PC = 0;
int Z = 0, C = 0, N = 0;
int running = 1;

int main(int argc, char *argv[]){
    int TestErreur=0; // Variable testée entre chaque étape qui prend une valeur ERREUR !=0 si une erreur est detectée dans une étape
    if (argc<2){
        printf("Erreur : Le nom du fichier d'entree n'est pas la.\n");return 1;}
    FILE *fichier=fopen(argv[1],"r");
    if (fichier==NULL){
        printf("Erreur : Le fichier d'entree n'a pas pu etre ouvert.\n");
        return 1;
    }
// apres les checkup de bases, on commence à lire le fichier ligne par ligne pour le premier passage
while (fgets(ligne,MAX_LIGNE_LONG, fichier)!=NULL) {
    ligne_num++;
    char *p=ligne;
    while ((*p==' ')||(*p=='\t')){p++;}
    if (*p=='\n'||*p==';'){
        continue; // ligne vide ou commentaire
    }
    // s'assure que la ligne est pas trop longue et vide la ligne si c'est le cas
    if ((occurence_char(p,'\n')==NULL)&&(!(feof(fichier)))){
        printf("Erreur : ligne %d trop longue \n", ligne_num);
        TestErreur=ERREUR;
        while (occurence_char(p,'\n')==NULL){
             if (fgets(ligne,MAX_LIGNE_LONG, fichier)==NULL){ break;}
            p=ligne;}
        continue;
    }

// lire jusqu’à ':' ou espace ou fin 
char *start = p;
while (*p != ':' && *p != '\0' && *p!=' ') {
    p++;
}
// etiquette detectée ?
if (*p == ':') {
    // On vérifie la taille dans le main, voir docu pour comprendre pourquoi
    int taille = p - start;
    if (taille >= MAX_ETIQ_LONG) { 
        printf("Erreur ligne : %d  Etiquette trop longue detectee\n",ligne_num);
    TestErreur=ERREUR;
    continue;}
    if (taille==0){
        printf("Erreur ligne : %d Etiquette vide detectee\n",ligne_num);
        continue;
    }
    char nom_etiquette[MAX_ETIQ_LONG];
    copier_char(nom_etiquette, start, taille + 1);
    Etiquette *Etiq=ajouter_etiquette(nom_etiquette);

    if (Etiq==NULL){
        TestErreur=ERREUR;}
    else{
        tab_etiq[nbEtiq]=Etiq;
        nbEtiq++;}

        
}
    adresse_courante += 4;}

fclose(fichier);
if (TestErreur==ERREUR){printf("Il y a eu une ou plusieurs erreurs indiques, la collecte des instructions ne va pas commencer\n");}

else{
    printf("La collecte des etiquettes c'est bien passe, la collecte des instructions va commencer\n");

// Maintenant on va classer les instructions :
// a ce stade on a déja fait les checkups de base
adresse_courante=0;
ligne_num=0;
fichier=fopen(argv[1],"r");
TestErreur=0;
while (fgets(ligne,MAX_LIGNE_LONG, fichier)!=NULL) {
    ligne_num++;
    char *p=ligne;
     while (*p==' '|| *p=='\t'){p++;}
    if (*p=='\n'||*p==';'){
        continue; // ligne vide ou commentaire
    }
    // Si étiquette sur la ligne, on la skip
    if (chercher_adresse_dans_etiquettes(adresse_courante)==1){
    while (*p!=':'){p++;}
        p++;
    }
    //on saute les espaces
    while ((*p==' ')||(*p=='\t')){p++;}
    if ((*p=='\n')||(*p=='\0')){
        printf("Erreur : Ligne %d avec etiquette mais sans instruction\n",ligne_num);
        adresse_courante+=4;
        TestErreur=ERREUR;
        continue;
    }

    // on découpe l'instruction pour isoler ses arguments et l'analyser plus simplement
    Instruction *instr=creer_instruction(p);
    if (instr==NULL){
        TestErreur=ERREUR;
    }
    else{
        tab_instr[nbInstr]=instr;
        nbInstr++;
    }
    adresse_courante+=4;
}
fclose(fichier);

if (TestErreur==ERREUR){
    printf("L'etape de creations d'instructions a rencontree des erreurs, la creation des instructions binaires ne peut donc pas avoir lieu. \n");}
else{
    // On entre dans la phase de création du fichier
    printf(" Les instructions ont bien ete prises en compte, la traduction et la creation du fichier en hexa va avoir lieu:\n");
    fichier=fopen("hexa.txt","w");
    if(fichier==NULL){
            printf("Erreur lors de création du fichier\n");
            TestErreur=ERREUR;
        }
    else{
    // on parcours chaque instruction
    for (int j=0;j<nbInstr;j++) {
    //on convertit en binaire
    if (TestErreur!=ERREUR){
    char *Inst_binaire = Instruction_binaire(tab_instr[j]);
    if(Inst_binaire==NULL){
            printf("Erreur lors de conversion en binaire\n");
            TestErreur=ERREUR;
            break;
        }
    // on convertit en hexa
    char *hex=Binaire32_vers_hexa(Inst_binaire);
    if (!hex) {
        printf("Erreur conversion instruction %d\n", j);
        TestErreur=ERREUR;
        break;
    }
    fprintf(fichier,"%s\n",hex);
    free(hex);
    free(Inst_binaire);
}
}
fclose(fichier);
    }



if (TestErreur==ERREUR){
    printf("Des erreurs ont ete rencontree lors de la creation du fichier hexa.txt\n");}

else{printf("La creation du fichier a bien abouti :) ! L'execution va commencer\n");
    srand(time(NULL)); 
    charger_programme("hexa.txt");
    
    // Initialisation
    PC = 0;
    running = 1; 
    unsigned long compteur_cycles = 0;
    
    printf("\n--- Debut de l'execution ---\n");

     while (running == 1) {
        compteur_cycles++;
        if (compteur_cycles > 1000000) {
            printf("Erreur : Temps d'execution depasse (> 1 000 000 cycles). Probable boucle infinie.\n");
            running = 0;
            break;
        }

        // FETCH
        if (PC > 65532) {
            printf("Erreur : PC hors limites (%d)\n", PC);
            running = 0;
            break;
        }
        unsigned int instruction = lire_mot_memoire(PC);
        PC += 4;

        // DECODE
        int code_op = masque_5bits(decalage_droite(instruction, 27)); 
        int rd = masque_5bits(decalage_droite(instruction, 22)); 
        int rn = masque_5bits(decalage_droite(instruction, 17)); 
        int bit_imm = masque_1bit(decalage_droite(instruction, 16));  

        // Calcul S avec extension de signe
        int S_valeur;
        if (bit_imm == 1) {
            short temp = (short)masque_16bits(instruction); 
            S_valeur = (int)temp; 
        } else {
            int rm = masque_5bits(instruction);
            S_valeur = registres[rm];
        }

        // EXECUTE
        long long resultat_temp;

        switch (code_op) {
            case 0: // OR
                registres[rd] = fonction_OU(registres[rn], S_valeur); 
                C = 0;
                break; 
            case 1: // AND
                registres[rd] = fonction_ET(registres[rn], S_valeur); 
                C = 0; 
                break; 
            case 2: // XOR
                registres[rd] = fonction_XOR(registres[rn], S_valeur); 
                C = 0; 
                break; 
            case 3: // ADD
                resultat_temp = (long long)registres[rn] + (long long)S_valeur;
                registres[rd] = (int)resultat_temp;
                if ((unsigned int)registres[rd] < (unsigned int)registres[rn]) C = 1; 
                else C = 0; 
                break;
            case 4: // SUB
                registres[rd] = registres[rn] - S_valeur;
                if ((unsigned int)registres[rn] < (unsigned int)S_valeur) C = 1; 
                else C = 0;
                break;
            case 5: // MUL
                registres[rd] = (short)masque_16bits(registres[rn]) * (short)masque_16bits(S_valeur);
                C = 0;
                break;
            case 6: // DIV
                if (S_valeur == 0) {
                    printf("Erreur : Division par zero impossible a l'instruction %d\n", (PC-4));
                    running = 0;
                }
                else if (registres[rn] == (-2147483647 - 1) && S_valeur == -1) {
                    printf("Erreur : Depassement de capacite (Overflow) lors de la division\n");
                    running = 0; 
                }
                else {
                    registres[rd] = registres[rn] / S_valeur;
                    C = 0;
                }
                break;

            case 7: // SHR
            {
                unsigned int u_rn = (unsigned int)registres[rn];

                if (S_valeur == 0) {
                    registres[rd] = registres[rn];
                    C = 0;
                }
                else if (S_valeur > 0) { 
                    if (S_valeur > 32) {
                        registres[rd] = 0; C = 0;
                    } 
                    else if (S_valeur == 32) {
                        registres[rd] = 0;
                        C = masque_1bit(decalage_droite(u_rn, 31));
                    } 
                    else {
                        C = masque_1bit(decalage_droite(u_rn, S_valeur - 1));
                        registres[rd] = decalage_droite(u_rn, S_valeur);
                    }
                } 
                else { // S_valeur < 0 (Gauche)
                    if (S_valeur < -32) {
                        registres[rd] = 0; C = 0;
                    }
                    else if (S_valeur == -32) {
                        registres[rd] = 0;
                        C = masque_1bit(u_rn);
                    }
                    else {
                        int n = -S_valeur;
                        C = masque_1bit(decalage_droite(u_rn, 32 - n));
                        registres[rd] = decalage_gauche(u_rn, n);
                    }
                }
            }
            break;

            case 12: // LDB
            {
                int adr = registres[rn] + S_valeur;
                if (adr < 0 || adr >= 65536) { 
                    running=0; 
                    printf("Erreur : Acces memoire invalide a l'adresse %d (LDB)\n", adr); 
                    break; 
                }
                registres[rd] = (int)(signed char)memoire[adr];
            }
            break;
            case 13: // LDH (Little Endian)
            {
                int adr = registres[rn] + S_valeur;
                if (adr < 0 || adr > 65534) { 
                    running=0; 
                    printf("Erreur : Acces memoire invalide a l'adresse %d (LDH)\n", adr); 
                    break; 
                }
                // L'octet à 'adr' est le poids faible, celui à 'adr+1' est le poids fort
                registres[rd] = (int)(short)(memoire[adr] + decalage_gauche(memoire[adr+1], 8));
            }
            break;
            case 14: // LDW
            {
                int adr = registres[rn] + S_valeur;
                if (adr < 0 || adr > 65532) { 
                    running=0; 
                    printf("Erreur : Acces memoire invalide a l'adresse %d (LDW)\n", adr); 
                    break; 
                }
                registres[rd] = lire_mot_memoire(adr);
            }
            break;
            case 15: // STB
            {
                int adr = registres[rd] + S_valeur;
                if (adr < 0 || adr >= 65536) { 
                    running=0; 
                    printf("Erreur : Ecriture hors memoire a l'adresse %d (STB)\n", adr); 
                    break; 
                }
                memoire[adr] = masque_octet(registres[rn]);
            }
            break;
            case 16: // STH 
            {
                int adr = registres[rd] + S_valeur;
                if (adr < 0 || adr > 65534) { running=0; printf("Erreur : Ecriture hors memoire a l'adresse %d (STH)\n", adr); break; }
                
                memoire[adr] = masque_octet(registres[rn]); 
                memoire[adr+1] = masque_octet(decalage_droite(registres[rn], 8));
            }
            break;

            case 17: // STW 
            {
                int adr = registres[rd] + S_valeur;
                if (adr < 0 || adr > 65532) { 
                    running=0;
                     printf("Erreur : Ecriture hors memoire a l'adresse %d (STW)\n", adr); 
                     break; 
                    }
                
                // on écrit à l'envers poids faible en premier (voir documentation)
                memoire[adr] = masque_octet(registres[rn]); 
                memoire[adr+1] = masque_octet(decalage_droite(registres[rn], 8));
                memoire[adr+2] = masque_octet(decalage_droite(registres[rn], 16));
                memoire[adr+3] = masque_octet(decalage_droite(registres[rn], 24));
            }
            break;

            // les sauts
            case 21: PC = masque_16bits(S_valeur); break; // JMP
            case 22: if (Z == 1) PC = masque_16bits(S_valeur); break; // JZS
            case 23: if (Z == 0) PC = masque_16bits(S_valeur); break; // JZC
            case 24: if (C == 1) PC = masque_16bits(S_valeur); break; // JCS
            case 25: if (C == 0) PC = masque_16bits(S_valeur); break; // JCC
            case 26: if (N == 1) PC = masque_16bits(S_valeur); break; // JNS
            case 27: if (N == 0) PC = masque_16bits(S_valeur); break; // JNC


            case 28: // IN
                printf("Entrez R%d : ", rd);
                if (scanf("%d", &registres[rd]) != 1) {
                    int c;
                    while ((c = recuperer_caractere()) != '\n' && c != EOF); 
                    registres[rd] = 0; 
                    printf("Saisie invalide. R%d mis a 0 par defaut.\n", rd);
                }
                break;
            case 29: // OUT
                printf("OUT R%d : %d\n", rd, registres[rd]);
                break;
            case 30: // RND
            {
                int min = registres[rn];
                int max = S_valeur;
                if (max <= min) {
                    printf("Avertissement : Intervalle RND invalide (Min %d >= Max %d). R%d prend la valeur Min.\n", min, max, rd);
                    registres[rd] = min; 
                } else {
                    long long ecart = (long long)max - (long long)min;
                    registres[rd] = min + (int)(rand() % ecart);
                }
            }
            break;

            case 31: // HLT
                printf("--- FIN DU PROGRAMME ---\n");
                running = 0;
                break;
                
            default:
                if(instruction != 0) {
                    printf("Erreur : Instruction inconnue ou invalide (Code : %d) a l'adresse %d\n", code_op, PC-4);
                    running = 0; 
                }
                break;
        }

        if (running == 0) break;
            
        // on met à jour les drapeaux
        if (code_op <= 7 || (code_op >= 12 && code_op <= 14) || code_op == 28 || code_op == 29) {
            
            // Mise à jour de Z (Zéro)
            if (registres[rd] == 0) {
                Z = 1;
            } else {
                Z = 0;
            }

            // Mise à jour de N (Négatif)
            if (registres[rd] < 0) {
                N = 1;
            } else {
                N = 0;
            }
            

            // pour les instructions 12, 13, 14 et 28, 29, il n'y a pas de retenue arithmétique donc on remet C à 0
            if ((code_op >= 12 && code_op <= 14) || code_op >= 28) { 
                C = 0; 
            }
        }
        else if (code_op == 15) { 
            signed char valeur_ecrite = (signed char)registres[rn];
            
            if (valeur_ecrite == 0) {
                Z = 1;
            } else {
                Z = 0;
            }

            if (valeur_ecrite < 0) {
                N = 1;
            } else {
                N = 0;
            }

            C = 0; 
        }

        else if (code_op == 16) { 
            short valeur_ecrite = (short)registres[rn];
            
            if (valeur_ecrite == 0) {
                Z = 1;
            } else {
                Z = 0;
            }

            if (valeur_ecrite < 0) {
                N = 1;
            } else {
                N = 0;
            }

            C = 0; 
        }
        else if (code_op == 17) { 
            
            if (registres[rn] == 0) {
                Z = 1;
            } else {
                Z = 0;
            }

            if (registres[rn] < 0) {
                N = 1;
            } else {
                N = 0;
            }

            C = 0; 
        }

        // on fait en sorte qu'on ait toujours r0 = 0
        registres[0] = 0; 
    }

    
}}}
// On free toutes la place en mémoire allouée aux instructions.
int k;
for(k=0;k<nbEtiq;k++){
    free(tab_etiq[k]->etiquette);
    free(tab_etiq[k]);
}
for(k=0;k<nbInstr;k++){
    free(tab_instr[k]);
}
return 0;
}
