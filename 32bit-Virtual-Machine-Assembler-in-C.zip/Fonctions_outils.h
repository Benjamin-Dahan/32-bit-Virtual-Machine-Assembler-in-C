#ifndef FONCTIONS_OUTILS_H
#define FONCTIONS_OUTILS_H
// Fonctions outils pour la Traduction Assembleur:

// renvoie la taille de la chaine de caractères donnée en entrée
int taille(char *mot);
// O si même chaine, 1 sinon    
int comparer_char(char *a,char *b);
// rencoie la taille de la liste de chaine de caractères donnée en entrée
int taille_liste_char(char **l);
// renvoie 1 si str dans tableau de str, 0 sinon;
int trouver_str(char *str, char**L);
// découpe une chaine de caractère en mots et les stocke dans un tableau de chaine de caractères
char **decouper_mots_virgules(char *s);
char *enlever_espace(char *s);
// permet de prendre une tranche d'un str ( de l'index I à j ( non inclus))
char *tranche_str(char *str, int i, int j);
// copie source dans dest en s'assurant de ne pas dépasser taille_dest
void copier_char(char *dest, char *source, int taille_dest);
// copie source dans des à partir de l'index j de dest
void copier_char_index(char *dest, char *source,int j);
// compte le nombre d'occurences de x dans p
char *occurence_char(char *p, char x);


// Fonctions outils pour l'Execution :

// Prototypes des fonctions
unsigned int decalage_droite(unsigned int valeur, int n);
unsigned int decalage_gauche(unsigned int valeur, int n);
unsigned int masque_octet(unsigned int valeur);
unsigned int masque_5bits(unsigned int valeur);
unsigned int masque_16bits(unsigned int valeur);
unsigned int masque_1bit(unsigned int valeur);

// Fonctions logiques manuelles
int fonction_ET(int a, int b);
int fonction_OU(int a, int b);
int fonction_XOR(int a, int b);

int recuperer_caractere();

#endif 