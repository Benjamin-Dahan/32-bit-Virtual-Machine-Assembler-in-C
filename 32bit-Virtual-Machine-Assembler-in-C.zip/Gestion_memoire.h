#ifndef GESTION_MEMOIRE_H
#define GESTION_MEMOIRE_H

#include <stdio.h>
#include <stdlib.h>
#include "Fonctions_outils.h" // Nécessaire pour les masques

// On rend la mémoire accessible aux autres fichiers (comme main.c)
extern unsigned char memoire[65536];

// Prototypes
void charger_programme(char* nom_fichier);
int lire_mot_memoire(int adresse);

#endif