#ifndef STRUCTURES_ET_FONCTIONS_ETIQUETTES_H
#define STRUCTURES_ET_FONCTIONS_ETIQUETTES_H



typedef struct{
    char *etiquette;
    unsigned int adresse;
} Etiquette;


// Rechercher une étiquette p partir de son nom, et renvoie un pointeur vers elle si elle existe ( sinon NULL);
Etiquette *chercher_etiquette(char *nom);
// Ajoute une étiquette dans la structure étiquette en détectant différentes erreurs
Etiquette  *ajouter_etiquette(char *nom);
// Cherche si il existe une etiquette à l'adresse donnée en entrée, si oui, renvoie 1 ( 0 sinon ).
int chercher_adresse_dans_etiquettes(unsigned int x);
//Fonctions d'affichage pour le débug 
void afficher_etiquettes();
#endif 