#include "Gestion_memoire.h"

unsigned char memoire[65536];

void charger_programme(char* nom_fichier) {
    FILE *fichier = fopen(nom_fichier, "r");
    if (fichier == NULL) {
        printf("Erreur : Impossible d'ouvrir le fichier %s\n", nom_fichier);
        exit(1);
    }

    unsigned int instruction_brute;
    int adresse_actuelle = 0;

    while (1) {
        int resultat_lecture = fscanf(fichier, "%x", &instruction_brute);
        
        if (resultat_lecture == EOF) {
            break; 
        }
        
        if (resultat_lecture != 1) {
            printf("Erreur critique : Contenu invalide (non-hex) dans le fichier a l'adresse %d.\n", adresse_actuelle);
            fclose(fichier);
            exit(1); 
        }

        if (adresse_actuelle + 3 >= 65536){
            printf("Attention : Le programme depasse la taille memoire (64ko). Troncation.\n");
            break;
        }

        memoire[adresse_actuelle]     = masque_octet(instruction_brute); // Poids faible en premier
        memoire[adresse_actuelle + 1] = masque_octet(decalage_droite(instruction_brute, 8));
        memoire[adresse_actuelle + 2] = masque_octet(decalage_droite(instruction_brute, 16));
        memoire[adresse_actuelle + 3] = masque_octet(decalage_droite(instruction_brute, 24));
        adresse_actuelle += 4;
    }
    fclose(fichier);
    printf("Programme charge : %d octets\n", adresse_actuelle);
}

int lire_mot_memoire(int adresse) {
    if (adresse < 0 || adresse > 65532) {
        printf("Erreur : Tentative de lecture d'instruction hors de la memoire (Adresse %d invalide)\n", adresse);
        return 0; 
    }
    
    unsigned int o1 = memoire[adresse];    
    unsigned int o2 = memoire[adresse + 1];
    unsigned int o3 = memoire[adresse + 2];
    unsigned int o4 = memoire[adresse + 3]; 
    
    return o1 + decalage_gauche(o2, 8) + decalage_gauche(o3, 16) + decalage_gauche(o4, 24);
}