#include "Fonctions_outils.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


int taille(char *mot){
    int i;
    for(i=0;*(mot+i)!='\0';i++){}
    return i;
}
int comparer_char(char *a,char *b){
    int i = 0;
    while (a[i] == b[i]) {
        if (a[i] == '\0') {return 0;}
        i++;
    }
    return 1;
}


int taille_liste_char(char **l){
    int i;
    for(i=0;*(l+i)!=NULL;i++){}
    return i;
}
int trouver_str(char *str, char**L){
    int i;
    for(i=0; i<taille_liste_char(L);i++){
        if(comparer_char(L[i],str)==0){return 1;}

    }
    return 0;
}
char **decouper_mots_virgules(char *s){
    int i=0;
    int nb_mots=0;

    if (s==NULL){
        return NULL;
    }

    // on compte les opérandes
    if (s[0]=='\0'){
        char **vide=malloc(sizeof(char*)*1);
        if(vide==NULL){
            return NULL;}
        vide[0]=NULL;
        return vide;
    }
    nb_mots = 1;
    for(i=0;s[i]!='\0';i++){
        if(s[i]==','){
            nb_mots++;
        }
    }

    char **tab = malloc(sizeof(char*)*(nb_mots+1));
    if(tab==NULL){
        return NULL;
    }

    // extraction des opérandes
    i=0;
    int k=0;
    int debut=0;

    while(1){
        if((s[i]==',')||(s[i]=='\0')){
            int len=i-debut;

            tab[k]=malloc(sizeof(char)*(len+1));
            if(tab[k]==NULL){
                int t;
                for(t=0;t<k;t++){
                free(tab[t]);}
                free(tab);
                return NULL;
            }
            int j;
            for(j=0;j<len;j++){
                tab[k][j]=s[debut+j];
            }
            tab[k][len]='\0';
            k++;
            if(s[i]=='\0'){
                break;
            }
            debut=i+1;
        }
        i++;
    }
    tab[k]=NULL;
    return tab;
}

char *tranche_str(char *str, int i, int j){
    if ((i<0)||(i>taille(str))||(j<i)||(j<0)||(j>taille(str))){
        return NULL;
    }
    int m;
    char *new=malloc(sizeof(char)*(j-i+1));
    if (new==NULL){
        return NULL;
    }

    for(m=i;m<j;m++){
        new[m-i]=str[m];}
    new[j-i]='\0';
return new;

    }

void copier_char(char *dest, char *source, int taille_dest) {
    int i;
    for (i=0;i<taille_dest-1&&source[i]!='\0';i++){
        dest[i]=source[i];
    }
    dest[i]='\0';
}

void copier_char_index(char *dest, char *source,int j) {
    int i;
    for (i=0;i<taille(source); i++) {
        dest[i+j] = source[i];
    
}}
char *occurence_char(char *p, char x){
    int i;
    for(i=0;i<taille(p);i++){
        if (*(p+i)==x){ return p+i;}
    }
    return NULL;
}
char *enlever_espace(char *s){
    int i = 0;
    int j;
    char *new;
    if(s==NULL){
        return NULL;
    }
    // enlever espaces à gauche
    while((s[i]==' ')||(s[i]=='\t')||(s[i]=='\n')){
        i++;
    }

    // enlever espaces à droite
    j=taille(s);
    while((j>i)&&((s[j-1]==' ')||(s[j-1]=='\t')||(s[j-1]=='\n'))){
        j--;
    }

    // allouer nouvelle chaine
    new=malloc(sizeof(char)*(j-i+1));
    if(new==NULL){
        return NULL;
    }

    int k;
    for(k=0;k<j-i;k++){
        new[k]=s[i+k];
    }
    new[j-i]='\0';

    return new;
}

unsigned int decalage_droite(unsigned int valeur, int n) {
    unsigned int resultat = valeur;
    for (int i = 0; i < n; i++) resultat /= 2;
    return resultat;
}

unsigned int decalage_gauche(unsigned int valeur, int n) {
    unsigned int resultat = valeur;
    for (int i = 0; i < n; i++) resultat *= 2;
    return resultat;
}

unsigned int masque_octet(unsigned int valeur) {
    return valeur % 256;
}

unsigned int masque_5bits(unsigned int valeur) {
    return valeur % 32;
}

unsigned int masque_16bits(unsigned int valeur) {
    return valeur % 65536;
}

unsigned int masque_1bit(unsigned int valeur) {
    return valeur % 2;
}

int fonction_ET(int a, int b) {
    unsigned int ua = (unsigned int)a;
    unsigned int ub = (unsigned int)b;
    unsigned int res = 0;
    unsigned int puis_de_2 = 1;

    for (int i = 0; i < 32; i++) {
        unsigned int bit_a = masque_1bit(ua);
        unsigned int bit_b = masque_1bit(ub);

        if (bit_a == 1 && bit_b == 1) {
            res = res + puis_de_2;
        }

        ua = ua / 2;
        ub = ub / 2;
        puis_de_2 = puis_de_2 * 2;
    }
    return (int)res;
}

int fonction_OU(int a, int b) {
    unsigned int ua = (unsigned int)a;
    unsigned int ub = (unsigned int)b;
    unsigned int res = 0;
    unsigned int puis_de_2 = 1;

    for (int i = 0; i < 32; i++) {
        unsigned int bit_a = masque_1bit(ua);
        unsigned int bit_b = masque_1bit(ub);

        if (bit_a == 1 || bit_b == 1) {
            res = res + puis_de_2;
        }

        ua = ua / 2;
        ub = ub / 2;
        puis_de_2 = puis_de_2 * 2;
    }
    return (int)res;
}

int fonction_XOR(int a, int b) {
    unsigned int ua = (unsigned int)a;
    unsigned int ub = (unsigned int)b;
    unsigned int res = 0;
    unsigned int puis_de_2 = 1;

    for (int i = 0; i < 32; i++) {
        unsigned int bit_a = masque_1bit(ua);
        unsigned int bit_b = masque_1bit(ub);

        if (bit_a != bit_b) {
            res = res + puis_de_2;
        }

        ua = ua / 2;
        ub = ub / 2;
        puis_de_2 = puis_de_2 * 2;
    }
    return (int)res;
}
// Utilisation du scanf
int recuperer_caractere() {
    char c;
    if (scanf("%c", &c) == 1) return (int)c;
    return EOF;
}