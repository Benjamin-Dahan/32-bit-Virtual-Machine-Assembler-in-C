#include "Fonctions_outils.h"
#include "Structures_et_Fonctions_instructions.h"
#include "Structures_et_Fonctions_etiquettes.h"
#include "Constantes.h"
#include <stdlib.h>
#include <stdio.h>
extern int ligne_num;
extern unsigned int adresse_courante;
extern Instruction *tab_instr[MAX_INSTR];
extern int nbInstr;

int opcode_valide_arg(int op){
    if(op==31){
        return 0;
    }

    if ((op<=9)||(op==30)){
        return 3;
    }
    if (op<=17){
        return 2;
    }
    return 1;
}
int numero_opcode(char *opcode){
    int i;
    char *liste_op[]={"or","and","xor","add","sub","mul","div","shr","ldb","ldh","ldw","stb","sth","stw","jmp","jzs","jzc","jcs","jcc","jns","jnc","in","out","rnd","hlt"};
    for(i=0;i<25;i++){
        if (comparer_char(opcode,liste_op[i])==0){
            if(i<8){
                return i;}
            if (i<14){
                return i+4;
            }
            return i+7;
            }   
        }
    
    return ERREUR;

}


// Les deux fonctions suivantes sont très importantes, elles permettent de convertir une chaine de str en long
// tout en s'assurant que : il n'y a pas d'overflow de l'utilisateur ( si il met #__LONG_MAX__+1 par exemple)
// que il y a bien des caractères à lire ( si l'utilisateur met # sans rien après)
// ou qu'il y a des caractères invalides #12PO par exemple
// et que le resultat represente bien un registre,  ou est representable sur 16 bits pour les Src
long conversion_char_long_src(char *s,long *out,int base) {
    char *end;
                       
    long v=strtol(s,&end,base);  
    if ((v>2000000000)||(v<-2000000000)){
        printf("Erreur ligne %d : Overflow critique\n",ligne_num);
    return 0;}
    if (end==s){                
        printf("Erreur ligne %d : aucun chiffre lu dans la valeur immediate\n",ligne_num);
        return 0;
    }
    if (*end!='\0'){    
        printf("Erreur! Caractere invalide ligne %d\n",ligne_num)   ;     
        return 0;
    }
    while(v<-32768){
        
        v=v+65536;
    }
    while (v>32767){
        v=v-65536;
        
    }
    *out = v;
    return 1;
}

long conversion_char_long_reg(char *s,long *out,int base) {
    char *end;                   
    long v=strtol(s, &end, base);  

    if ((v>2000000000)||(v<-2000000000)){
        printf("Erreur ligne %d : Overflow critique\n",ligne_num);
        return 0;}
    if (end==s){                
        printf("Erreur ligne %d : Le numero du registre absent\n",ligne_num);
        return 0;
    }
    if (*end!='\0'){    
        printf("Erreur! Caractere invalide ligne %d\n",ligne_num);     
        return 0;
    }
    while(v<0){
        v=v+32;
        
    }
    while (v>31){
        v=v-32;
        
    }
    *out = v;
    return 1;
}

// s'occupe de rd si p=1, rn si p=0;
//renvoie 1 si succès, 0 sinon
int verif_reg(Instruction *current,char *str,int p){
    int i;
    if (str[0]!='r'){
        printf("Erreur : Argument invalide ligne %d\n",ligne_num);
        return 0;
    }
    long reg;
    char *t1=tranche_str(str,1,taille(str));
    if(t1==NULL){
        return 0;
    }
    if(conversion_char_long_reg(t1,&reg,10)){
    if(p==1){
    current->Rd=reg;}
    else{
    current->Rn=reg;
    }
    i=1;
    }
    else{
        i=0;
        }
    free(t1);

    return i;
}




// permet de s'assurer du type de Src et de le mettre proprement
// p=0 si Src est une valeur Imm ou un registre, p=1 si Src est une valeur Imm,une etiquette ou un registre 
int verif_Src(Instruction *current,char *str,int p){
    int a=1; // nous permet de faire la différence entre une adresse portant le nom d'un registre et un registre. Si une etiquette  a le nom d'un registre, alors les saut vers l'adresse contenue dans ce registre ne marcheront plus, le saut se fera vers l'etiquette a la place
    long Src=0;
    int i=0;
    if (taille(str)<=1){
            printf("Erreur : Il manque la valeur immediate ligne %d\n",ligne_num);
            return 0;
        }
    if (str[0]=='#'){
        if (str[1]=='h'){
            char *t3=tranche_str(str,2,taille(str));
            if (t3==NULL){
                printf("Erreur : Allocation Memoire\n");
                return 0;
            }
                if (conversion_char_long_src(t3,&Src,16)){
                    current->Src2=Src;
                    current->Imm=1;
                    i=1;
                }
                else{
                    i=0;}
                free(t3);
            } 
        else{
            char *t3=tranche_str(str,1,taille(str));
            if (t3==NULL){
                printf("Erreur : Allocation Memoire\n");
                return 0;
            }
                if (conversion_char_long_src(t3,&Src,10)){
                    current->Src2=Src;
                    current->Imm=1;
                    i=1;
                }
                else{
                    i=0;}
                free(t3);
        }
    return i;
    }
    if (p==1){

        Etiquette *etiq=chercher_etiquette(str); 
        if (etiq==NULL){ 
            if(str[0]=='r'){
                a=0;
            }
            else{
            printf("Erreur : L'etiquette ligne %d n'existe pas \n",ligne_num); 
            i=0; } }
        else{ current->Src2=etiq->adresse;
            current->Imm=1;
        i=1;}
        if(a==1){
        return i;}
    }
    if (str[0]!='r'){
        printf("Erreur : Registre invalide ligne %d\n",ligne_num);
        return 0;
    }
    char *t1=tranche_str(str,1,taille(str));
    if (t1==NULL){
        printf("Erreur : Allocation Memoire\n");
                return 0;
            }
    if(conversion_char_long_reg(t1,&Src,10)){
    current->Src2=Src;
    current->Imm=0;
    i=1;
    }
    else{
        i=0;
    }
    free(t1);
    return i;
}
Instruction *creer_instruction(char *p){
    if (taille(p)==0){
        printf("Erreur: Instructions vide ligne %d\n",ligne_num);
        return NULL;
    }
char *start=p;   
int o;

while((*p!='\0')&&(*p!=' ')&&(*p!='\t')&&(*p!='\n')){
    p++;}


int taille2=p-start;


char *Opcode=malloc(sizeof(char)*(taille2+1));
if(Opcode==NULL){ 
    printf("Erreur : Allocation Mémoire ligne\n");
    return NULL;
 }
for(o=0;o<taille2;o++){
    Opcode[o]=start[o];
}
Opcode[taille2]='\0';
while((*p==' ')||(*p=='\t')||(*p=='\n')){
    p++;
}
char **instruction=decouper_mots_virgules(p);
if(instruction == NULL) {
    printf("Erreur : Allocation Mémoire ligne\n");
    return NULL;
 }

for(o=0; o<taille_liste_char(instruction); o++){
    char *tmp = enlever_espace(instruction[o]);
    free(instruction[o]);
    instruction[o] = tmp;
}



    if (instruction==NULL){
        return NULL;
    }
    int flagos=1;
    if(nbInstr>=MAX_INSTR){
        printf("Erreur : Nombre trop importants d'instructions atteints\n");
        return NULL;
    }

    int op=numero_opcode(Opcode);
    if (op==ERREUR){
        printf("Erreur : Opcode inconnu ligne %d\n",ligne_num);
        return NULL;
    }

    int arg=opcode_valide_arg(op);
    if (arg!=(taille_liste_char(instruction))){
        printf("Erreur : Mauvais nombre d'arguments ligne %d \n", ligne_num);
        return NULL;
    }

    Instruction *current=malloc(sizeof(Instruction));
    if (current==NULL){
        printf("Erreur : Allocation Memoire\n");
        return NULL;
    }
    current->Opcode=op;
    current->Rd=0;  
    current->Rn=0;
    current->Imm=0;
    current->Src2=0;

    if (op==31) return current;

    if ((op<8)||(op==30)){
        if(!verif_reg(current,instruction[0],1)){
            flagos=ERREUR;
        }
        if(!verif_reg(current,instruction[1],0)){
            flagos=ERREUR;
        }
        if(!verif_Src(current,instruction[2],0)){
            flagos=ERREUR;
        }
    }
    if ((op>=12)&&(op<=14)){
        if(!verif_reg(current,instruction[0],1)){
            flagos=ERREUR; }
        if(instruction[1][0]!='('){
            printf("Erreur: Format invalide ligne %d\n",ligne_num);
            flagos=ERREUR;
        }
        if (flagos!=ERREUR){
        int j;
        // on se place après les parenthèses
        for(j=0;(instruction[1][j]!=')')&&(instruction[1][j]!='\0');j++){}
        if(instruction[1][j]=='\0'){
            printf("Erreur: Format invalide ligne %d\n",ligne_num);
            flagos=ERREUR;
        }
        if (flagos!=ERREUR){
        char *t2=tranche_str(instruction[1],1,j);
        if(t2==NULL){
            printf("Erreur : Allocation Memoire\n");
            flagos=ERREUR;
        }
        else {
        if(!verif_reg(current,t2,0)){
            flagos=ERREUR; }}
        free(t2);
        char *t3=tranche_str(instruction[1],j+1,taille(instruction[1]));
        if(t3==NULL){
        printf("Erreur : Allocation Memoire\n");
            flagos=ERREUR;}
        else{ if (!verif_Src(current,t3,0)){
            flagos=ERREUR;
        }
    }
        free(t3);
    }
}}

    if ((op>=15)&&(op<=17)){

        if(!verif_reg(current,instruction[1],0)){
            flagos=ERREUR; }
        
        if(instruction[0][0]!='('){
            printf("Erreur: Format invalide ligne %d\n",ligne_num);
            flagos=ERREUR;
        }
        if (flagos!=ERREUR){
        int j;
        // on se place après les parenthèses
        for(j=0;((instruction[0][j]!=')')&&(instruction[0][j]!='\0'));j++){}
        if(instruction[0][j]=='\0'){
            printf("Erreur: Format invalide ligne %d\n",ligne_num);
            flagos=ERREUR;
        }
        if (flagos!=ERREUR){
        char *t2=tranche_str(instruction[0],1,j);
        if(t2==NULL){
            printf("Erreur : Allocation Mémoire\n");
            flagos=ERREUR;
        }

        else { if(!verif_reg(current,t2,1)){
            flagos=ERREUR; }}
        free(t2);
        char *t3=tranche_str(instruction[0],j+1,taille(instruction[0]));
        if(t3==NULL){
            printf("Erreur : Allocation Mémoire\n");
            flagos=ERREUR;
        }
        else {if(!verif_Src(current,t3,0)){
            flagos=ERREUR;
        }}
        free(t3);
    }
}
    }

    if ((op>=21)&&(op<=27)){
        if(!verif_Src(current,instruction[0],1)){
            flagos=ERREUR;
        }
    }
    if ((op==28)||(op==29)){
        if(!verif_reg(current,instruction[0],1)){
            flagos=ERREUR;
        }
    }
    for(o=0; o<taille_liste_char(instruction); o++){
    free(instruction[o]);
}
free(instruction);

    if (flagos == ERREUR){
        free(current);
        return NULL;
    }

    return current;
}

// Fonction d'affichage pour le débug
// fonctions d'affichage/ debug
void afficher_liste_char( char **l){
    int i;
    for(i=0;i<taille_liste_char(l);i++){
        printf("%s\n",*(l+i));
    }
    return;

}
void afficher_instructions(Instruction *L[]){
    int i;
    for(i=0;i<nbInstr;i++){
        printf("Instructions numero : %d\nOpcode: %d\nRd : %ld\nRn= %ld\nImm= %d\nSRC= %ld\n",i+1,L[i]->Opcode,L[i]->Rd,L[i]->Rn,L[i]->Imm,L[i]->Src2);
    }
    return;
}
void afficher_instruction(Instruction *L){
    printf("Opcode : %d \n Rd : %ld \n Rn=%ld,\n Imm = %d \n SRC=%ld\n",L->Opcode,L->Rd,L->Rn,L->Imm,L->Src2);
    
    return;
}
