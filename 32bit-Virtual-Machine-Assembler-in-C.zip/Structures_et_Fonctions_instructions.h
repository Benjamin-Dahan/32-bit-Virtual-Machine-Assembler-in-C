#ifndef STRUCTURES_ET_FONCTIONS_INSTRUCTIONS_H
#define STRUCTURES_ET_FONCTIONS_INSTRUCTIONS_H

// Structure pour stocker les instructions
typedef struct {
    int Opcode;   
    long Rd;                         
    long Rn;                         
    int Imm;                     
    long Src2;
} Instruction;
// renvoie le numéro de l'opcode de l'instruction, ERREUR si l'opcode n'existe pas
int numero_opcode(char *opcode);
// renvoie le nombre d'argument attendu en fonction du code opératoire de l'instruction
int opcode_valide_arg(int op);
// lit la chaine de caractères s en base "base" et la convertit en valeurs décimale qu'on stock dans out
// renvoie 1 si succès, 0 sinon
// le programme s'assure que la valeur décimale peut être représentée sur 16 bits signés
long conversion_char_long_src(char *s,long *out,int base);
// lit la chaine de caractères s en base "base" et la convertit en valeurs décimale qu'on stock dans out
// renvoie 1 si succès, 0 sinon
// le programme s'assure que la valeur décimale peut être représentée sur 5 bits non signés
long conversion_char_long_reg(char *s,long *out,int base);
// prend une chaine de caracères représentant le registre d'une instructions, s'assure du bon format,
//la convertit en décimale et remplit le champ associé dans l'instruction.
// 1 si succès, 0 sinon
int verif_reg(Instruction *current,char *str,int p);
// prend une chaine de caracères représentant le champ S d'une instructions, s'assure du bon format,
//l'interprète de la bonne façon, la convertit en décimale et remplit le champ associé dans l'instruction.
// 1 si succès, 0 sinon
int verif_Src(Instruction *current,char *str,int p);
// Prend une liste de chaine de caractères représentant une instruction en entrée, la traite et initialise une instruction
// et remplit tout ses champs
// renvoie un pointeur vers l'instruction si tout est bon, NULL sinon.
Instruction *creer_instruction(char *p);

// fonctions d'affichage pour le débug:
void afficher_liste_char(char **L);
void afficher_instruction(Instruction *L);
void afficher_instructions(Instruction *L[]);
#endif 