#ifndef CONSTANTES_H
#define CONSTANTES_H

#define ERREUR -5 // code d'erreur général-> Le main ne passera pas à l'étape suivante 
#define MAX_LIGNE_LONG     256   // longueur maximum d'une ligne du fichier
#define MAX_ETIQ_LONG     51   // longueur maximum d'une étiquette
#define MAX_INSTR        4096  // nombre maximum d'instruction
#define MAX_ETIQ      1024  // nombre maxiumum d'étiquette
#endif