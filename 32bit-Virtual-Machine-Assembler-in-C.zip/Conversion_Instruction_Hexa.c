#include "Conversion_Instruction_Hexa.h"
#include "Structures_et_Fonctions_instructions.h"
#include "Fonctions_outils.h"
#include <stdlib.h>
#include <stdio.h>
int power(int x, int n){
    int i;
    int sum=1;
    for(i=0;i<n;i++){
        sum=sum*x;
    }
    return sum;
}

char *convertion_binaire_sans_signe(int n, int bits) {
    if (bits <= 0) return NULL;
    if (n < 0) {
        printf("Erreur : %d negatif pour non signe\n", n);
        return NULL;
    }
    if (n > power(2,bits) - 1) {
        printf("Erreur : %d non representable sur %d bits\n", n, bits);
        return NULL;
    }
    
    int i;
    int j;
    char *binaire=malloc(sizeof(char)*bits+1);
    if (binaire==NULL){
        printf("Erreur : Allocation mémoire\n");
        return NULL;}
    for(i=bits-1;i>=0;i--){
        j=power(2,i);
        if (j<=n){
            binaire[bits-1-i]='1';
            n=n-j; }
        else{
            binaire[bits-1-i]='0';
        }

    }
    binaire[bits]='\0';
    return binaire;

}




char *convertion_binaire_signe(int n, int bits) {
    int min=-power(2,bits-1);
    int max=power(2,bits-1)-1;
    if ((n<min)||(n>max)){
        printf("Erreur : %d non representable en complement a 2 sur %d bits\n", n, bits);
        return NULL;
    }
    int val;
    if (n>=0){
        val=n;}
    else{
        val=power(2,bits)+n;  
    } 

    return convertion_binaire_sans_signe(val, bits);
}



char *Instruction_binaire(Instruction *I){
    char *op=convertion_binaire_sans_signe(I->Opcode,5);
    char *rd=convertion_binaire_sans_signe(I->Rd,5);
    char *rn=convertion_binaire_sans_signe(I->Rn,5);
    char *Imm=convertion_binaire_sans_signe(I->Imm,1);
    char *Src=convertion_binaire_signe(I->Src2,16);
    char *Instr=malloc(sizeof(char)*32+1);
    if (Instr==NULL){
        printf("Erreur : Allocation mémoire\n");
        return NULL;
    }
    copier_char_index(Instr,op,0);
    copier_char_index(Instr,rd,5);
    copier_char_index(Instr,rn,10);
    copier_char_index(Instr,Imm,15);
    copier_char_index(Instr,Src,16);
    Instr[32]='\0';
    free(op);
    free(rd);
    free(rn);
    free(Imm);
    free(Src);
    return Instr;
}


char *Binaire32_vers_hexa(char *m){
    int i;
    int j;
    int val;
    char *hexa=malloc(sizeof(char)*9);
    if (hexa==NULL){
        printf("Erreur : Allocation mémoire\n");
        return NULL;
    }
    char *bout;
    for(i=0;i<8;i++){
        j=0;
        val=0;
        bout=tranche_str(m,i*4,(i+1)*4);
        if(bout==NULL){
            printf("Erreur : Allocation mémoire\n");
        return NULL;
    }
        for(j=0;j<4;j++){
            val=val+(bout[j]-'0')*power(2,3-j);
        }
        if (val<=9){
            hexa[i]=val+'0';
        }
        if (val==10){hexa[i]='A';}
        if (val==11){hexa[i]='B';}
        if (val==12){hexa[i]='C';}
        if (val==13){hexa[i]='D';}
        if (val==14){hexa[i]='E';}
        if (val==15){hexa[i]='F';}
        free(bout);

    }
    hexa[8]='\0';

    return hexa;
}